import { Component, OnInit } from '@angular/core';

// import { TodoListItemComponent } from './todolist-item/todolist-item.component';

@Component({
  selector: 'app-todolist',
  templateUrl: './todolist.component.html',
  styleUrls: ['./todolist.component.css']
})
export class TodolistComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
